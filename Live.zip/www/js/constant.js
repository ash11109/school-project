//live  
// const Config = {
//     api_url: "https://teamka.in/crm1/APIs/api_development.php",
//     domain : "https://teamka.in"
// };
//dev
let selectedFiles = []; // Files selected but not uploaded
const Config = {
    api_url: "https://teamka.in/crm1/APIs/api_development.php",
    domain : "https://school-project-one-steel.vercel.app/www/",
    //domain : "http://localhost/live/www/",
    autoAssignUrl : "https://teamka.in/crm1/APIs/"
};
// const Config = {
//     api_url: "http://localhost/live/APIs/api_development.php",
//     domain : "https://school-project-one-steel.vercel.app/www/",
//     //domain : "http://localhost/live/www/",
//     autoAssignUrl : "http://localhost/live/APIs/"
// };