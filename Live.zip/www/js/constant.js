//live  
// const Config = {
//     api_url: "https://teamka.in/crm1/APIs/api_development.php",
//     domain : "https://teamka.in"
// };
//dev
const Config = {
    api_url: "https://teamka.in/crm1/APIs/api_development.php",
    domain : "https://school-project-one-steel.vercel.app/www/"
};